
python main/train_ddpm.py +dataset=celebamaskhq128/train \
                     ddpm.data.root='/home/sirui/DiffuseVAE/dataset/CelebAMask-HQ/CelebAMask-HQ' \
                     ddpm.data.name='celebamaskhq' \
                     ddpm.data.norm=True \
                     ddpm.data.hflip=True \
                     ddpm.model.dim=128 \
                     ddpm.model.dropout=0.1 \
                     ddpm.model.attn_resolutions=\'16,\' \
                     ddpm.model.n_residual=2 \
                     ddpm.model.dim_mults=\'1,2,2,3,4\' \
                     ddpm.model.n_heads=8 \
                     ddpm.training.type='form1' \
                     ddpm.training.cfd_rate=0.0 \
                     ddpm.training.epochs=1000 \
                     ddpm.training.z_cond=False \
                     ddpm.training.batch_size=8 \
                     ddpm.training.vae_chkpt_path=\'/home/sirui/DiffuseVAE/25/celebmask50/checkpoints/vae-cmhq128_alpha=100-epoch=499-train_loss=0.0000.ckpt\' \
                     ddpm.training.device=\'gpu:0\' \
                     ddpm.training.results_dir=\'/home/sirui/DiffuseVAE/25/celebmask50/ddpm\' \
                     ddpm.training.workers=1 \
                     ddpm.training.chkpt_prefix=\'celebahq128_rework_form1__21stJune_sota_nheads=8_dropout=0.1\'

