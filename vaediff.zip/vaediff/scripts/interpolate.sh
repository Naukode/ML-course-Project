python main/eval/ddpm/interpolate_vae.py +dataset=celebamaskhq128/test \
                            ddpm.data.norm=True \
                            ddpm.model.attn_resolutions=\'16,\' \
                            ddpm.model.dropout=0.1 \
                            ddpm.model.n_residual=2 \
                            ddpm.model.dim_mults=\'1,2,2,3,4\' \
                            ddpm.model.n_heads=8 \
                            ddpm.evaluation.guidance_weight=0.0 \
                            ddpm.evaluation.seed=1 \
                            ddpm.evaluation.chkpt_path=\'/home/sirui/DiffuseVAE/vanilla/diffvae_chq128_form1_loss=0.0066.ckpt\' \
                            ddpm.evaluation.type='form1' \
                            ddpm.evaluation.resample_strategy='truncated' \
                            ddpm.evaluation.skip_strategy='uniform' \
                            ddpm.evaluation.sample_method='ddpm' \
                            ddpm.evaluation.sample_from='target' \
                            ddpm.evaluation.temp=1.0 \
                            ddpm.evaluation.save_path=\'/home/sirui/DiffuseVAE/vanilla/ddpm1/home/sirui/DiffuseVAE/vanilla/1\' \
                            ddpm.evaluation.z_cond=False \
                            ddpm.evaluation.n_steps=1000 \
                            ddpm.evaluation.save_vae=True \
                            ddpm.evaluation.workers=1 \
                            vae.evaluation.chkpt_path=\'/home/sirui/DiffuseVAE/vanilla/vae_chq128_alpha=1.0_loss=0.0000.ckpt\' \
                            vae.evaluation.expde_model_path=\'/home/sirui/DiffuseVAE/vanilla/gmm_100.joblib\' \



