


python main/eval/ddpm/sample.py +dataset=celebahq/test \
                        ddpm.evaluation.chkpt_path='/home/sirui/DiffuseVAE/result/celebahq/ddpm/checkpoints/ddpm.ckpt' \
                        ddpm.evaluation.type='uncond' \
                        ddpm.evaluation.skip_strategy='quad' \
                        ddpm.evaluation.sample_method='ddpm' \
                        ddpm.evaluation.sample_from='target' \
                        ddpm.evaluation.temp=1.0 \
                        ddpm.evaluation.save_path='/home/sirui/DiffuseVAE/result/celebahq/ddpm/uncond' \


