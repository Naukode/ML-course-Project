
python main/train_ae.py +dataset=celebamaskhq128/train \
                     vae.data.root='/home/sirui/DiffuseVAE/dataset/CelebAMask-HQ/CelebAMask-HQ/' \
                     vae.data.name='celebamaskhq' \
                     vae.data.hflip=True \
                     vae.training.batch_size=42 \
                     vae.training.log_step=50 \
                     vae.training.epochs=500 \
                     vae.training.device=\'gpu:0\' \
                     vae.training.results_dir=\'/home/sirui/DiffuseVAE/25/celebmask25\' \
                     vae.training.workers=2 \
                     vae.training.chkpt_prefix=\'cmhq128_alpha=100\' \
                     vae.training.alpha=100\
                     vae.training.c_max=25\
                     vae.training.c_stop_iter=3e5



