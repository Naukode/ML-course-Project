python main/extract_latents.py extract --device gpu:0 \
                                --dataset-name celebahq \
                                --image-size 256 \
                                --save-path ~/celebahq_latents/ \
                                '/data1/kushagrap20/vae-celebahq256_alpha=1.0_Jan31-epoch=499-train_loss=0.0000.ckpt' \
                                ~/datasets/celeba_hq/

